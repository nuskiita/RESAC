
library(GPArotation)



replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,5)
conver <- 0.000001
maxiter <- 250





sesgores1 <- matrix(NA, ncol=numitems, nrow=replicas)
sesgores2 <- matrix(NA, ncol=numitems, nrow=replicas)

for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1:2]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)
  Res <- cor(data)
  diag(Res) <- 1
  doublets <- LargestDoubletsEREC(data, r=numfactor, cor=1, Res)$doublets
  resu <- Morgana(Res, r=numfactor, conver,maxiter, doblets = doublets)



  A <- resu$L
  rotated_matrix <- oblimin(A)
  A <- rotated_matrix$loadings



  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <- Tloads-A
  } else{
    A0 <- A
    A[,1] <- A0[,2]
    A[,2] <- A0[,1]

    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <- Tloads-A
  }



  sesgores1[i, ] <- sesgoloads[,1]
  sesgores2[i, ] <- sesgoloads[,2]
  print(i)
}




p11 <- (sesgores1)^2
p11
p12 <- (sesgores2)^2
p12
sqrt(colSums(p11)/500)
sqrt(colSums(p12)/500)

sqrt(colSums(p11)/500)
[1] 0.1211715 0.1447376 0.1435400 0.1422517 0.1247793 0.1114888 0.1140795 0.1151199
> sqrt(colSums(p12)/500)
[1] 0.1024043 0.1061155 0.1116402 0.1084907 0.1130147 0.1221436 0.1180486 0.1199288
>

library(GPArotation)



replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
conver <- 0.000001
maxiter <- 250





sesgores1 <- matrix(NA, ncol=numitems, nrow=replicas)


for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)
  Res <- cor(data)
  diag(Res) <- 1
  doublets <- LargestDoubletsEREC(data, r=numfactor, cor=1, Res)$doublets
  resu <- Morgana(Res, r=numfactor, conver,maxiter, doblets = doublets)



  A <- resu$L




  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}

    sesgoloads <- A-Tloads
  }



  sesgores1[i, ] <- sesgoloads[,1]

  print(i)
}




p11 <- (sesgores1)^2
p11

sqrt(colSums(p11)/500)
