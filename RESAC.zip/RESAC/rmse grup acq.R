replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,5)
conver <- 0.000001
maxiter <- 250



library(siren)

sesgoacq1 <- matrix(NA, ncol=numitems, nrow=replicas)
sesgoacq2 <- matrix(NA, ncol=numitems, nrow=replicas)

for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1:2]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)
  result <- acquihybrid(data, content_factors=numfactor, tar, corr="Pearson")
  A <- result$loadings[,1:2]





  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <- Tloads-A
  } else{
    A0 <- A
    A[,1] <- A0[,2]
    A[,2] <- A0[,1]

    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <- Tloads-A
  }



  sesgoacq1[i, ] <- sesgoloads[,1]
  sesgoacq2[i, ] <- sesgoloads[,2]
  print(i)
}




p11 <- (sesgoacq1)^2
p11
p12 <- (sesgoacq2)^2
p12
sqrt(colSums(p11)/500)
sqrt(colSums(p12)/500)




replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
conver <- 0.000001
maxiter <- 250



library(siren)

sesgoacq <- matrix(NA, ncol=numitems, nrow=replicas)

for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1:2]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)
  result <- acquihybrid(data, content_factors=numfactor, tar, corr="Pearson")
  A <- result$loadings[,1:2]





  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}

    sesgoloads <- A-Tloads
  }



  sesgoacq[i, ] <- sesgoloads[,1]

  print(i)
}




p11 <- (sesgoacq)^2
p11

sqrt(colSums(p11)/500)
sqrt(colSums(p12)/500)

