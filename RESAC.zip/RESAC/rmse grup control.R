

library(psych)
sesgocontrol1 <-sesgocontrol2 <- matrix(NA, ncol=numitems, nrow=replicas)
for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1:2]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)
  control <- fa(data, nfactors=numfactor, rotate="oblimin", residuals=TRUE)
  A <- control$loadings[1:numitems,]





  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <-Tloads-A
  } else{
    A0 <- A
    A[,1] <- A0[,2]
    A[,2] <- A0[,1]

    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <- Tloads-A
  }



  sesgocontrol1[i, ] <- sesgoloads[,1]
  sesgocontrol2[i, ] <- sesgoloads[,2]
  print(i)
}

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,5)
conver <- 0.000001
maxiter <- 250


g1control1 <- sesgocontrol1
g1control2 <- sesgocontrol2

p11 <- (sesgocontrol1)^2
p11
p12 <- (sesgocontrol2)^2
p12
sqrt(colSums(p11)/500)
sqrt(colSums(p12)/500)



sesgocontrol<- matrix(NA, ncol=numitems, nrow=replicas)
for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)
  control <- fa(data, nfactors=numfactor, rotate="oblimin", residuals=TRUE)
  A <- as.matrix(control$loadings[1:numitems,])



  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}

    sesgoloads <- Tloads-A
  }


  sesgocontrol[i, ] <- sesgoloads[,1]

  print(i)
}

replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
conver <- 0.000001
maxiter <- 250




p11 <- (sesgocontrol)^2
p11
p12 <- (sesgocontrol2)^2
p12
sqrt(colSums(p11)/500)
sqrt(colSums(p12)/500)

