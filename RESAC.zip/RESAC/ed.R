#############################
###                       ###
###           ed          ### 
###                       ###
#############################

ed <- function(s){
  
  
  #[u, v]
  source("sort.R")
  source("nrm.R")
  tol <- .Machine$double.eps
  values <- eigen(s)$values
  vectors <- eigen(s)$vectors 
  p <- length(values)
  v <- sort(values)$vector_sort
  j <- p:1
  v <- v[j]
  v <- diag(v)
  u <- u[,j]
  u <- nrm(u)
  
  
  return(list(values=values, vectors=vectors))
}
