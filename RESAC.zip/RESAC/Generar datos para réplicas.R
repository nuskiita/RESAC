



# 1 Genero lambdas de 0.65 para un factor y para dos. Los items pares son negativos y los impares positivos. 


lambdas <- function(numitems, numfactor){
  
  if(numfactor == 1){
    matriz <- matrix(0.65, nrow = numitems, ncol=1)
    m <- rep(c(1, -1), (numitems/2))
    matriz <- matriz*m
  }
  else{
    m <- rep(c(1,-1), (numitems/2))
    a <- matrix(c(rep(0.65, (numitems/2)), rep(0, (numitems/2))),ncol=1)
    a <- a*m
    b <- matrix(c(rep(0, (numitems/2)), rep(0.65, (numitems/2))),ncol=1)
    b <- b*m
    matriz <- as.matrix(cbind(a,b), nrow= numitems, ncol=2)
    
  }
  return(matriz)
  
}

# 2. Definir patrones de aquiescencia.
# necesitamos numitems  NUMERO DE ITEMS. Los patrones de ACQ son 4 que se clasifican por h (homo y hetero) y por s(tama?o)

ACQpat <- function(numitems, h, size){
  if(size==1){
    a <- matrix(0.15, nrow=numitems, ncol=1)
  } else{ 
    a <- matrix(0.25, nrow=numitems, ncol=1)}
  
  if(h==2){
    b <- rnorm(numitems, 0, 0.05)
    matriz <- matrix(c(a+b), ncol=1)
  } else{ matriz <- a}
  return(matriz)
}

# 3. Definir matriz ph seg?n numero de factores

phmat <- function(numfactor){
  PH <- diag(numfactor+1) 
  return(PH)
}


# 4. Definir el residual. El residual puede ser grande, peque?o, positivo, negativo, estar en el mismo sitio o en distinto lugar. 
# N = numero de sujetos 
# Place <- la localizaci?n seran los siguientes: (1,2) (1,3) (1,5) y (1,6)
# res puede ser 0 u otro valor 

residualplace <- function(N, numitems, res, place){
  e <- rnorm(N*numitems, mean=0, sd=1)
  
  if(res!=0){
    E <- matrix(e, ncol=numitems, nrow=N)
    placea <- place[1]
    placeb <- place[2]
    E[,placeb] <- res*E[,placea]+ sqrt(1-(res^2)) * E[,placeb]
  } else {
    E <- matrix(e, ncol=n, nrow=N)
  }
  
  return(E)
}


# 5. Definir matriz U segun el n?mero de factores 
# 
umat <- function(numfactor, L, a){
  if (numfactor==1){
    U <- diag(as.vector(sqrt(1-(L^2)-(a^2))))
  }
  else{
    U <- diag(as.vector(sqrt(1-(L[,1]^2)-(L[,2]^2)-(a^2))))
  }
 return(U)
}

# 6. Definir matriz th segun el n?mero de factores 
# 
thmat <- function(numfactor){
  
  PH <- phmat(numfactor)
  
  mth <- matrix(0, nrow=N, ncol= (numfactor+1))
  for(i in 1: (numfactor+1)){
    mth[,i] <- rnorm(N, mean=0,sd=1)
  }
  c1 <- var(mth)
  chol1 <- solve(chol(c1))
  TH1 <-  mth %*% chol1
  chol2 <- chol(PH)
  TH <- TH1 %*% chol2 * sd(mth[,ncol(mth)]) + mean(mth[,ncol(mth)])
  
  return(TH)
  
}
 

#7.  Definir la base de datos uniendo las funciones anteriores: 


bbdd <- function(N, numfactor, numitems, h, size, res, place){
  
  l <- lambdas(numitems, numfactor)
  a <- ACQpat(numitems, h, size)
  
  L <- cbind(l,a)
  
  PH <- phmat(numfactor)
  TH <- thmat(numfactor)
  
  U <- umat(numfactor, l, a)
  E <- residualplace(N, numitems, res, place)
  
  Zpre <- (L%*%t(TH))+(U%*%t(E))
  Z <- t(Zpre)
  
  c1 <- "V"
  c2 <- 1:ncol(Z)
  
  columnas <- as.vector(paste(c1, c2, sep=""))
  colnames(Z) <- columnas
  
  
  return(list(Z=Z, L=L))
}


N <- 200
oilnumfactor <- 1
numitems <- 6
h<- 1
size<- 1
res<-0.2
place <- c(1,3)


bbdd(200, numfactor=1,numitems=6, h=1, size=1,res=0.12, place=c(1,3))

# 8. Cargar el paquete siren y proceder con la correcci?n
# 

library(siren)

# 8.1. Hacer el target.

target<- function(numitems, numfactor){
  if(numfactor ==2){
    m <- rep(c(9,-9), (numitems/2))
    a <- matrix(c(rep(1, (numitems/2)), rep(0, (numitems/2))),ncol=1)
    a <- a*m
    b <- matrix(c(rep(0, (numitems/2)), rep(1, (numitems/2))),ncol=1)
    b <- b*m
    
    matriz <- cbind(a,b)
  } else{
    matriz<- matrix(c(rep(c(9, -9), (numitems/2))), ncol=1 )
  }
  return(matriz)
  
} 

## 8.2. No voy a usar el aquihybrid sino el extraction ya que quiero sacar la matriz residual. 

data <- bbdd(200, numfactor=1,numitems=6, h=1, size=1,res=0.20, place=c(1,3))
data <- as.matrix(data$Z)
tar <- target(6, 1)

result <- acquiextraction(data, n_factors=1,corr="Pearson",raw_data=TRUE)
resi <- result$Res
correl <- cor(data)
correl - resi

# 8.3. crear un LargestDoubletsEREC para que acepte matrices 
#
LargestDoubletsEREC <- function(X, r, cor, R){
  
  
  N <- nrow(X)
  m <- ncol(X)
  conver <- 0.00001
  
  Ledermann <- floor((2*m+1-sqrt(8*m+1))/2)
  df <- 1/2 * ((m-r) * (m-r+1)) - m
  # max number of doblets
  nd <- Ledermann - r
  if((df - nd) < 1){
    nd <- df - 1
  }
   
  if(cor>1){
    Ac <- as.matrix(my_minres_hc(R, r, conver, N)$Loadings)
  } else{
    Ac <- as.matrix(my_minres(R, r, conver, N)$Loadings)
  }

 
  
  
  PairOut <- zeros(2,1)
  m_Core <- m-2
  Core <- zeros(m_Core, 1)
  RESFREE <- eye(m)
  IPSIs <- c()
  PPP <- matrix(0, nrow = 0, ncol = nrow(PairOut))
  
  
  d <- 0
  columna <- fila<- c()
  
  for (i in 1:(m-1)) {
    for (j in (i+1):m) {
      PairOut <- matrix(0, nrow = 2, ncol = 1)
      PairOut[1, 1] <- i
      PairOut[2, 1] <- j
      PPP <- rbind(PPP, t(PairOut))
      k <- 1
      Core <- integer(m-2)
      for (h in 1:m) {
        if (h != i && h != j) {
          Core[k] <- h
          k <- k + 1
        }
      }
      
      # inestable 
      RCore <- R[Core, Core]
      
      if(cor>1){
        Ac <- my_minres_hc(RCore, r, conver, N)$Loadings
      } else{
        Ac <- as.matrix(my_minres(RCore, r, conver, N)$Loadings)
      }
      
      # opci?n estable
      
      # Ac <- A[Core, ]
      
      
      lam <- zeros(2,r)
      for(h in 1:2){
        SelExtension <- c(PairOut[h,1], t(Core))
        R_Ex <- R[SelExtension, SelExtension]
        vecr <- R_Ex[(2:(m_Core+1)), 1]
        vecr <- as.matrix(vecr, ncol=1)
        lam[h,] <- (solve(t(Ac)%*%Ac))%*%t(Ac)%*%vecr
      }
      # Residual covariances 
      
      RESFREE[PairOut[1,1], PairOut[2,1]] <- R[PairOut[1,1], PairOut[2,1]]-crossprod(lam[1,], lam[2,])
      RESFREE[PairOut[2,1], PairOut[1,1]] <- RESFREE[PairOut[1,1], PairOut[2,1]]
      d <- d+1
    }
    
    # Collection of IPSIS for correcting EPC1
    
    Li <- rbind(Ac, lam)
    Core <- as.matrix(Core)
    temp <- as.matrix(order(c(Core, PairOut)))
    Li <- Li[temp,]
    
    
    IPSIi <- as.matrix(diag(1, nrow=m)- diag(diag(Li%*%(t(Li)))))^(-0.5)
    diagIPSIi <- t(as.matrix(diag(IPSIi)))
    IPSIs<- rbind(IPSIs, diagIPSIi)
    
  }
  Ips <- matrix(0, nrow=nd, ncol=m)
  for(i in 1:nd){
    for(j in 1:m){
      if(IPSIs[i,j]< 0.001){
        IPSIs[i,j] <- max(IPSIs)
      } else{IPSIs[i,j] <- IPSIs[i,j]}
    }
  }
  source("colmin.R")
  IPSI <- diag(colmin(IPSIs))
  EREC <- IPSI%*%RESFREE%*%IPSI
  
  total_pairs <- m*(m-1)/2
  EREC_row <- c(total_pairs)
  Pair <- zeros(total_pairs, 2)
  h <- 1
  
  for(i in 1:(m-1)){
    for(j in (i+1):m){
      Pair[h,1] <- i
      Pair[h,2] <- j
      EREC_row[h] <- abs(EREC[i,j])
      h <- h+1
    }
  }
  EREC_row_sort <- sort(EREC_row, descend=TRUE)[,1]
  J <- sort(EREC_row, descend=TRUE)[,2]
  
  
  
  doublets <- zeros(nd, 3)
  for(i in 1:nd){
    doublets[i, 1] <- Pair[J[i],1]
    doublets[i, 2] <- Pair[J[i],2]
    doublets[i, 3] <- EREC_row[J[i]]
  }
  
  result <- list(doublets=doublets, nd=nd)
  return(result)
  
}



Morgana <- function(R, r, conver, maxiter, doblets){
  
  
  
  m <- ncol(R)
  
  # Computes the matrix of partial correlations 
  # AI is Guttman's AntiImage matrix, and P the matrix of partial correltaions 
  
  D  <- diag(diag(solve(R))) # solve = a ^(-1)
  tmp0 <- diag(D^(-1/2))
  AI <- diag(tmp0)%*%solve(R)%*%diag(tmp0)
  P <- (2* eye(m))-AI
  
  
  Pr <- eye(m)
  
  d <- nrow(doblets)
  tmp <- ncol(doblets)
  
  for(i in 1:d){
    Pr[doblets[i,1],doblets[i,2]] <- doblets[i,3] * sign(P[doblets[i,1], doblets[i,2]])
    Pr[doblets[i,2],doblets[i,1]] <- Pr[doblets[i,1], doblets[i,2]]
  }
  
  # initial estimated solution (no iterations)
  
  U <- diag(diag(D^(-1/2)))
  RESI <- U%*%Pr%*%U
  
  # RESI includes PHI2  in the diagonal and the correlated residuals off-diagonal
  
  RED <- R-RESI
  
  # A is the orthogonal pattern in r factors based on the complete residual matrix
  source("pcaR.R")
  L <- pcaR(RED, r)$A
  
  f <- sum(diag(t(L)%*%L))
  
  fold <- f*10
  
  iter <- 1
  
  while (abs(f - fold) > conver) {
    W <- R - (L %*% t(L))
    UU <- diag(diag(W))
    U <- sqrt(UU)
    RED <- R - (U %*% Pr %*% U)
    result <- pcaR(RED, r)
    B <- result$B
    L <- result$A
    iter <- iter + 1
    fold <- f
    
    if (iter < maxiter) {
      f <- sum(diag(t(L) %*% L))
    }
  }
  
  
  RESCOV <- R-(L%*%t(L))  
  RESI <- solve(U)%*% RESCOV%*%solve(U)
  RESCOR <- eye(m)
  
  for(i in 1:d){
    RESCOR[doblets[i,1],doblets[i,2]] = RESI[doblets[i,1],doblets[i,2]];
    RESCOR[doblets[i,2],doblets[i,1]] = RESI[doblets[i,2],doblets[i,1]];
  }
  results <- list(L=L, RESCOV=RESCOV, RESCOR=RESCOR)
  return(results)
}



### 8.3. Una parte importante es que la diagonal de Res tiene que ser de 1
### 
Res <- correl - resi
diag(Res) <- 1
dob <- LargestDoubletsEREC(data, r=1, cor=1, Res)$doublets


Morgana(Res, r=numfactor, conver=0.00005,maxiter=100, doblets = dob)
conteo <- sum(dob[,3]>0.25)
## conteo nos sirve para saber el n?mero de dobletes mayores de 0,2

filas <- dob[,3]>=0.2
dobby <- dob[filas, ]




# R?plicas 





replicas<- 1



N <- 1000
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.20
place <- c(1,3)

replicascompletas <- function(replicas, N, numfactor, numitems, h, size, res, place){
  conteo <- 0
  dobby <- matrix(NA, ncol = 3, nrow = 0)
  matrixsesgos1 <- matrixsesgos2 <- matrix(0, ncol=numitems, nrow=replicas)
  RMSEA1 <- CFI1 <- TL1<- c()
  for(i in 1: replicas){
    
    data <- bbdd(N, numfactor,numitems, h, size,res, place)
    
    Tloads <- data$L[,-(ncol(data$L))]
    data <- as.matrix(data$Z)
    correl <- cor(data)
    tar <- target(numitems, numfactor)
    # extraccion
    result <- acquiextraction(data, n_factors=numfactor,corr="Pearson",raw_data=TRUE)
    resi <- result$Res
    # morgana
    Res <- correl - resi
    diag(Res) <- 1
    dob <- LargestDoubletsEREC(data, r=2, cor=1, Res)$doublets
    MOR <- Morgana(as.matrix(Res), r=numfactor, conver,maxiter, doblets = dob)
    
    
    A <- MOR$L
    if(A[1,1]<0){A <- A*(-1)}
    sesgoloads <- A-Tloads
    
    
    matrixsesgos1[i,] <- sesgoloads[,1]
    matrixsesgos2[i,] <- sesgoloads[,2]
    
    
    
    
    
    RESCOV <- MOR$RESCOV
    RESCOR <- MOR$RESCOR
    doubletsEFA <- dob
    nd <- nrow(doubletsEFA)
    RES <- zeros(nd, 3)
    for (k in 1:nd) {
      RES[k, 1] <- doubletsEFA[k, 1]
      RES[k, 2] <- doubletsEFA[k, 2]
      RES[k, 3] <- RESCOR[doubletsEFA[k, 1], doubletsEFA[k, 2]]
    }
    
    result <- LoseferMorganaH0(A, RESCOR, doubletsEFA[, c(1, 2)], N, 5000)
    v <- result$v
    vv <- result$vv
    a_n <- result$a_n
    b1_n <- result$b1_n
    b2_n <- result$b2_n
    a_f <- result$a_f
    b_f <- result$b_f
    c_f <- result$c_f
    d_f <- result$d_f
    
    result <- LoseferMorgana(Res, A, N, RESCOR, nd, v, vv, a_n, b1_n, b2_n, a_f, b_f, c_f, d_f, display=1)
    Um1 <- result$Um
    d1 <- result$d
    
    
    
    RMSEA1[i] <- result$RMSEA
    CFI1[i] <- result$CFI
    TL1[i] <- result$TL
    
    
    # sesgo loadings
    #sesgo <- (Tloads-Loads) 
    
    
    
    conteo <- c(conteo, sum(dob[,3]>0.25))
    filas <- dob
    dobby <- rbind(dobby, dob)
  }
  
  # ahora a?adir las variables
  
  nf <- rep(numfactor, length(conteo)) #numero factor
  ni <- rep(numitems, length(conteo)) #numero items
  
  placeb <- place[2]    #signo 0 es entre dos items positivos
  if(placeb%%2 == 0){
    signo <- rep(1, length(conteo))
  } else{signo <- rep(0, length(conteo))}
  
  acqh <- rep(h, length(conteo))
  acqsize <- rep(size, length(conteo)) 
  
  residual <- rep(res, length(conteo))
  pla <- rep(numfactor, length(conteo))
  
  
  
  nf1 <- rep(numfactor, nrow(dobby))
  ni1 <- rep(numitems, nrow(dobby))
  
  placeb <- place[2]
  if(placeb%%2 == 0){
    signo1 <- rep(1, nrow(dobby))
  } else{signo1 <- rep(0, nrow(dobby))}
  
  acqh1 <- rep(h, nrow(dobby))
  acqsize1 <- rep(size, nrow(dobby)) 
  
  residual1 <- rep(res, nrow(dobby))
  pla1 <- rep(numfactor, nrow(dobby))
  
  numerodobletes <- cbind(conteo, nf, ni, acqh, acqsize, residual, pla, signo)
  dobletesencontrados <- cbind(dobby, nf1, ni1, acqh1, acqsize1, residual1, pla1, signo1)
  
  return(list(numerodobletes=numerodobletes, dobletesencontrados=dobletesencontrados, matrixsesgos=matrixsesgos, RMSEA1=RMSEA1, CFI1=CFI1 , TL1=TL1))
}





replicasnosiren <- function(replicas, N, numfactor, numitems, h, size, res, place){
  conteo <- c()
  dobby <- matrix(NA, ncol = 3, nrow = 0)
  for(i in 1: replicas){
    
    data <- bbdd(N, numfactor,numitems, h, size,res, place)
    Tloads <- data$L[,-(ncol(data$L))]
    data <- as.matrix(data$Z)
    #tar <- target(numitems, numfactor)
    # extraccion
    #result <- acquiextraction(data, n_factors=numfactor,corr="Pearson",raw_data=TRUE)
    
    # morgana
    Res <- cor(data)
    diag(Res) <- 1
    dob <- LargestDoubletsEREC(data, r=1, cor=3, Res)$doublets
    #Loads <- Morgana(as.matrix(Res), r=numfactor, conver,maxiter, doblets = dob)$L
    
    # sesgo loadings
    #sesgo <- (Tloads-Loads) 
    
    
    
    conteo <- c(conteo, sum(dob[,3]>0.25))
    filas <- dob[,3]
    dobby <- rbind(dobby, dob)
  }
  
  # ahora a?adir las variables
  ######################
  nf <- rep(numfactor, length(conteo))
  ni <- rep(numitems, length(conteo))
  
  placeb <- place[2]
  if(placeb%%2 == 0){
    signo <- rep(1, length(conteo))
  } else{signo <- rep(0, length(conteo))}
  
  acqh <- rep(h, length(conteo))
  acqsize <- rep(size, length(conteo)) 
  
  residual <- rep(res, length(conteo))
  pla <- rep(numfactor, length(conteo))
  
  
  nf1 <- rep(numfactor, nrow(dobby))
  ni1 <- rep(numitems, nrow(dobby))
  
  placeb <- place[2]
  if(placeb%%2 == 0){
    signo1 <- rep(1, nrow(dobby))
  } else{signo1 <- rep(0, nrow(dobby))}
  
  acqh1 <- rep(h, nrow(dobby))
  acqsize1 <- rep(size, nrow(dobby)) 
  
  residual1 <- rep(res, nrow(dobby))
  pla1 <- rep(numfactor, nrow(dobby))
  ############################
  numerodobletes <- cbind(conteo, nf, ni, acqh, acqsize, residual, pla, signo)
  dobletesencontrados <- cbind(dobby, nf1, ni1, acqh1, acqsize1, residual1, pla1, signo1)
  
  return(list(numerodobletes=numerodobletes, dobletesencontrados=dobletesencontrados))
}

replicas <- 2
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,6)
conver <- 0.0005
maxiter <- 250


replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

KKK<-replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)
KKK
