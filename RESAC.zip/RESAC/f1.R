# f1: funcion 1 a igualar a 0 en Newton-Raphson
# 
# primera ecuaci�n del sistema: sesgo
# 

f1 <- function(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6) {
  tmp1 <- x^2 * (1 - (x * t3))
  tmp2 <- y^2 * (pt2 - (y * pt3))
  tmp3 <- x * y * ((2 * c1) - (3 * x * c2) - (3 * y * c3))
  
  f1 <- tmp1 + tmp2 + tmp3 - 1
  
  return(f1)
}
