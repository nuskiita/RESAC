

flfunc <- function(b,c,d,skew, kurtosis){
  abc <- fleishman(b, c, d)
  x <- abc$var
  y <- abc$skew
  z <- abc$kurt
  
  h1 <- x-1
  h2 <- y - skew
  h3 <- z - kurtosis
  f <- matrix(c(h1, h2, h3), nrow=3)
  return(f)
}


