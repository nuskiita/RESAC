
#ORROWN(A,B)               Order B from A by Index of Congruence by Tuckey
#                         A -> First  Matrix
#                         B -> Second Matrix
#                         L -> B in the new order

orrown <- function(A, B, PHI) {
  C <- abs(congru(A, B))
  n <- nrow(C)
  
  maximo <- matrix(0, nrow = n, ncol = 3)
  for (h in 1:n) {
    for (i in 1:n) {
      for (j in 1:n) {
        if (abs(maximo[h, 1]) < abs(C[i, j])) {
          maximo[h, 1] <- C[i, j]
          maximo[h, 2] <- i
          maximo[h, 3] <- j
        }
      }
    }
    for (i in 1:n) {
      C[maximo[h, 2], i] <- 0
    }
    for (i in 1:n) {
      C[i, maximo[h, 3]] <- 0
    }
  }
  
  L <- matrix(0, nrow = n, ncol = 0)
  for (i in 1:n) {
    for (j in 1:n) {
      if (maximo[j, 2] == i) {
        L <- cbind(L, B[, maximo[j, 3]])
      }
    }
  }
  
  C <- matrix(0, nrow = n, ncol = 0)
  for (i in 1:n) {
    for (j in 1:n) {
      if (maximo[j, 2] == i) {
        C <- cbind(C, PHI[, maximo[j, 3]])
      }
    }
  }
  
  D <- matrix(0, nrow = 0, ncol = n)
  for (i in 1:n) {
    for (j in 1:n) {
      if (maximo[j, 2] == i) {
        D <- rbind(D, C[maximo[j, 3], ])
      }
    }
  }
  
  c <- diag(congru(A, L))
  I <- diag(n)
  for (i in 1:n) {
    if (c[i] < 0) {
      I[i, i] <- -1
    }
  }
  L <- L %*% I
  D <- D %*% I
  D <- t(D) %*% I
  
  return(list(L = L, D = D))
}
