# f2: funcion 2 a igualar a 0 en Newton Raphson
# 
# segunda ecuaci�n del sistema: curtosis



f2 <- function(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6) {
  tmp1 <- (t4 * x^4) + (pt4 * y^4)
  tmp2 <- 4 * (x^3) * y * c4
  tmp3 <- 4 * (y^3) * x * c5
  tmp4 <- 6 * (x^2) * (y^2) * c6
  f2 <- tmp1 + tmp2 + tmp3 + tmp4 - 3
  
  return(f2)
}

