
# TARROTOB : semi-specified oblique rotation
# 
# Ff  <- Factor solution to be rotated
# Tt <- tranformation matrix
# W <- Target binari matrix

tarrotob <- function(Ff, W, conv) {
  m <- nrow(Ff)
  r <- ncol(Ff)
  TA <- diag(r)
  PHI <- diag(r)
  A <- Ff %*% TA
  
  f1 <- 0
  for (g in 1:m) {
    for (h in 1:r) {
      f1 <- f1 + (A[g, h] - W[g, h] * A[g, h])^2
    }
  }
  
  f1old <- f1
  iter <- 1
  again <- 1
  
  while (again == 1) {
    for (g in 1:r) {
      for (h in 1:r) {
        if (g != h) {
          agg <- 0
          bgg <- 0
          bgh <- 0
          for (j in 1:m) {
            agg <- agg + ((1 - W[j, g]) * A[j, g]^2)
            bgg <- bgg + ((1 - W[j, h]) * A[j, g]^2)
            bgh <- bgh + ((1 - W[j, h]) * A[j, g] * A[j, h])
          }
          
          delta <- (bgh - PHI[g, h] * agg) / (agg + bgg)
          gamma <- sqrt(delta^2 + 2 * PHI[g, h] * delta + 1)
          
          for (j in 1:m) {
            A[j, h] <- (-1.0 * delta * A[j, g]) + A[j, h]
            A[j, g] <- gamma * A[j, g]
          }
          
          for (j in 1:r) {
            TA[j, h] <- (-1.0 * delta * TA[j, g]) + TA[j, h]
            TA[j, g] <- gamma * TA[j, g]
          }
          
          for (j in 1:r) {
            PHI[g, j] <- (PHI[g, j] + delta * PHI[h, j]) / gamma
          }
          PHI[g, g] <- 1
          for (j in 1:r) {
            PHI[j, g] <- PHI[g, j]
          }
        }
      }
    }
    
    f1old <- f1
    
    f1 <- 0
    for (g in 1:m) {
      for (h in 1:r) {
        f1 <- f1 + (A[g, h] - W[g, h] * A[g, h])^2
      }
    }
    
    if (f1 < 0.1 * conv) {
      again <- 0
    }
    
    if (abs(f1 - f1old) < conv) {
      again <- 0
    }
    
    if (iter > 50) {
      again <- 0
    }
    
    iter <- iter + 1
  }
  
  ST <- A %*% PHI
  Tt <- TA
  
  return(list(A = A, Tt = Tt, PHI = PHI, ST = ST))
}