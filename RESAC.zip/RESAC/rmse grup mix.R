library(GPArotation)



replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 2
res <- 0.1
place <- c(1,3)
conver <- 0.000001
maxiter <- 250





sesgomix1 <- matrix(NA, ncol=numitems, nrow=replicas)
sesgomix2 <- matrix(NA, ncol=numitems, nrow=replicas)

for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1:2]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)




  result <- acquihybrid(data, content_factors=numfactor, tar, corr="Pearson")


  Res <-result$resid_matrix
  diag(Res) <- 1
  doublets <- LargestDoubletsEREC(data, r=numfactor, cor=1, Res)$doublets
  resu <- Morgana(Res, r=numfactor, conver,maxiter, doblets = doublets)



  A <- resu$L
  rotated_matrix <- varimax(A)
  A <- rotated_matrix$loadings[1:8,1:2]



  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <- Tloads-A
  } else{
    A0 <- A
    A[,1] <- A0[,2]
    A[,2] <- A0[,1]

    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
    if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
    sesgoloads <- Tloads-A
  }



  sesgomix1[i, ] <- sesgoloads[,1]
  sesgomix2[i, ] <- sesgoloads[,2]
  print(i)
}




p11 <- (sesgomix1)^2
p11
p12 <- (sesgomix2)^2
p12
sqrt(colSums(p11)/500)
sqrt(colSums(p12)/500)




replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
conver <- 0.000001
maxiter <- 250





sesgores1 <- matrix(NA, ncol=numitems, nrow=replicas)


for(i in 1:replicas){

  #gerera datos
  dat <- bbdd(N, numfactor,numitems, h, size,res, place)
  Tloads <- dat$L[,1]
  data <- as.matrix(dat$Z)
  tar <- target(numitems, numfactor)
  Res <- cor(data)
  diag(Res) <- 1
  doublets <- LargestDoubletsEREC(data, r=numfactor, cor=1, Res)$doublets
  resu <- Morgana(Res, r=numfactor, conver,maxiter, doblets = doublets)



  A <- resu$L




  if(abs(A[1,1])>0.1){
    if(A[1,1]<0){A[,1] <- A[,1]*(-1)}

    sesgoloads <- A-Tloads
  }



  sesgores1[i, ] <- sesgoloads[,1]

  print(i)
}




p11 <- (sesgores1)^2
p11

sqrt(colSums(p11)/500)
