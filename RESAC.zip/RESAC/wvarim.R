wvarim <- function(F1, conv, nrs) {
  n <- nrow(F1)
  m <- ncol(F1)
  
  eig <- eigen(F1 %*% t(F1))
  Q <- eig$vectors
  D <- diag(eig$values)
  F <- Q[,1:m] %*% sqrt(D[1:m,1:m])
  
  tau <- diag(sign(F[, 1]))
  H <- diag(F %*% t(F))^(-1/2)
  H <- diag(H)
  G1 <- tau %*% H 
  G <- G1%*%F
  
  c <- sqrt(1/m)
  acos_c <- acos(c) * 360 / (2 * pi)
  
  A <- G
  W <- c()
  
  
  for (i in 1:n) {
    aij <- A[i, 1]
    acos_a <- acos(aij) * 360 / (2 * pi)
    
    if (aij < c) {
      W[i] <- cos(((acos_a - acos_c) / (90 - acos_c) * 90) * 2 * pi / 360)^2 + 0.001
    } else {
      W[i] <- cos(((acos_c - acos_a) / acos_c * 90) * 2 * pi / 360)^2 + 0.001
    }
   
  }
  
  W <- diag(W)
  A <- W %*% A
  
  r <- ncol(A)
  m <- nrow(A)
  
  f <- 0
  
  for (nos in 1:(nrs + 1)) {
    if (nos == 1) {
      T <- diag(ncol(A))
    } else {
      T <- qr.Q(orth(matrix(runif(ncol(A) ^ 2) - 0.5, ncol = ncol(A))))
    }
    
    B <- A %*% T
    f <- sum((B * B) - matrix(rowMeans(B * B), nrow = m, ncol = r))^2
    fold <- f - 2 * conv * f
    
    
    if (f == 0) {
      fold <- -conv
    }
    
    
    iter <- 0
    
    while (f - fold > f * conv) {
      fold <- f
      iter <- iter + 1
      
      for (i in 1:r) {
        for (j in (i + 1):r) {
          x <- B[, i]
          y <- B[, j]
          xx <- T[, i]
          yy <- T[, j]
          u <- crossprod(x)-crossprod(y)
          v <- 2 * x * y
          u <- u - rowMeans(u)
          v <- v - rowMeans(v)
          a <- 2 * sum(u * v)
          b <- sum(crosprod(u)) - sum(crosprod(v))
          c <- (a^2 + b^2)^0.5
          e <- sum(t(u) %*% u) - sum(t(v)%*% v)
          if (a >= 0) {
            signe <- 1
          }
          if (a < 0) {
            signe <- -1
          }
          
          if (c < 1e-11) {
            print('No rotation anymore')
            cosi <- 1
            sin <- 0
            fr <- 0
            ir <- 0
            Tr <- eye(r)
            return()
          }
          
          if (c >= 1e-11) {
            vvv <- -signe * ((b + c) / (2 * c))^0.5
            sin <- (0.5 - 0.5 * vvv)^0.5
            cosi <- (0.5 + 0.5 * vvv)^0.5
          }
          
          v <- cosi * x - sin * y
          w <- cosi * y + sin * x
          vv <- cosi * xx - sin * yy
          ww <- cosi * yy + sin * xx
          
          if (vvv >= 0) {
            B[, i] <- (v)
            B[, j] <- (w)
            T[, i] <- (vv)
            T[, j] <- (ww)
          }
          if (vvv < 0) {
            B[, j] <- (v)
            B[, i] <- (w)
            T[, j] <- (vv)
            T[, i] <- (ww)
          }
        }
      }
      
      f <- sum((B * B) - rowMeans(B * B))^2
    }
    
    if (nos == 1) {
      fr <- f
      ir <- iter
      Tr <- T
    } else if (f > fr) {
      fr <- f
      ir <- iter
      Tr <- T
    }
  }
  
  # The resulting rotated matrix and additional information will be in Tr, fr, and ir variables.
  
  
  I <- diag(r)
  A <- F %*% Tr
  for (i in 1:r) {
    if (sum(A[, i]) < 0) {
      I[i, i] <- -1
    }
  }
  
  Tr <- Tr %*% I
  A <- F %*% Tr
  
  Tr <- solve(t(F1) %*% F1) %*% t(F1) %*% A
  
  return(list(Tr = Tr, W = W, fr = fr, ir = ir))
}
