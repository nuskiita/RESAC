

rand <- function(nrow, ncol){
  l <- nrow *ncol
  vector <- rnorm(l)
  
  matriz <- matrix(vector, nrow=nrow, ncol=ncol)
  return(matriz)
}
rand(2,3)
