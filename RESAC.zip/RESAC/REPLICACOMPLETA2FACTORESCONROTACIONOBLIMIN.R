# replicas completas cuando hay dos factores


replicascompletas <- function(replicas, N, numfactor, numitems, h, size, res, place){
  conteo <- 0
  dobby <- matrix(NA, ncol = 3, nrow = 0)
  matrixsesgos1 <- matrixsesgos2 <- matrixsesgos3 <- matrix(0, ncol=numitems, nrow=replicas)
  RMSEA1 <- CFI1 <- TL1<- c()
  for(i in 1: replicas){
    
    data <- bbdd(N, numfactor,numitems, h, size,res, place)
    
    Tloads <- data$L[,-(ncol(data$L))]
    Tacq <- data$L[,(ncol(data$L))]
    data <- as.matrix(data$Z)
    correl <- cor(data)
    tar <- target(numitems, numfactor)
   
    
    
     # extraccion
    result <- acquihybrid(data, content_factors=2,target = tar, corr = "Pearson", raw_data=TRUE, method = "fixed", display = TRUE)
    resi <- result$resid_matrix
    acq_est <- result$loadings[,3]
    # morgana
    #Res <- correl - resi
    Res <- resi
    diag(Res) <- 1
    dob <- LargestDoubletsEREC(data, r=numfactor, cor=1, Res)$doublets
    MOR <- Morgana(as.matrix(Res), r=numfactor, conver,maxiter, doblets = dob)
    
    
    A <- MOR$L
    
    #library(psych)
    
    
    # Realizar la rotaci�n oblimin
    rotated_matrix <- oblimin(A)
    A <- rotated_matrix$loadings
    
    
    
    
    
    
    if(abs(A[1,1])>0.1){
      sesgoloads <- A-Tloads
    } else{
      A0 <- A
      A[,1] <- A0[,2]
      A[,2] <- A0[,1]
      
      if(A[1,1]<0){A[,1] <- A[,1]*(-1)}
      if(A[5,2]<0){A[,2] <- A[,2]*(-1)}
      sesgoloads <- A-Tloads
    }
    
    
    sesgoacqui <- acq_est -Tacq
    
    matrixsesgos1[i,] <- sesgoloads[,1]
    matrixsesgos2[i,] <- sesgoloads[,2]
    matrixsesgos3[i,] <- sesgoacqui
    
    
    
    
    RESCOV <- MOR$RESCOV
    RESCOR <- MOR$RESCOR
    doubletsEFA <- dob
    nd <- nrow(doubletsEFA)
    RES <- zeros(nd, 3)
    for (k in 1:nd) {
      RES[k, 1] <- doubletsEFA[k, 1]
      RES[k, 2] <- doubletsEFA[k, 2]
      RES[k, 3] <- RESCOR[doubletsEFA[k, 1], doubletsEFA[k, 2]]
    }
    
    result <- LoseferMorganaH0(A, RESCOR, doubletsEFA[, c(1, 2)], N, 5000)
    v <- result$v
    vv <- result$vv
    a_n <- result$a_n
    b1_n <- result$b1_n
    b2_n <- result$b2_n
    a_f <- result$a_f
    b_f <- result$b_f
    c_f <- result$c_f
    d_f <- result$d_f
    
    result <- LoseferMorgana(Res, A, N, RESCOR, nd, v, vv, a_n, b1_n, b2_n, a_f, b_f, c_f, d_f, display=1)
    Um1 <- result$Um
    d1 <- result$d
    
    
    
    RMSEA1[i] <- result$RMSEA
    CFI1[i] <- result$CFI
    TL1[i] <- result$TL
    
    
    # sesgo loadings
    #sesgo <- (Tloads-Loads) 
    
    
    
    conteo <- c(conteo, sum(dob[,3]>0.25))
    filas <- dob
    dobby <- rbind(dobby, dob)
  }
  
  # ahora a?adir las variables
  
  nf <- rep(numfactor, length(conteo)) #numero factor
  ni <- rep(numitems, length(conteo)) #numero items
  
  placeb <- place[2]    #signo 0 es entre dos items positivos
  if(placeb%%2 == 0){
    signo <- rep(1, length(conteo))
  } else{signo <- rep(0, length(conteo))}
  
  acqh <- rep(h, length(conteo))
  acqsize <- rep(size, length(conteo)) 
  
  residual <- rep(res, length(conteo))
  pla <- rep(numfactor, length(conteo))
  
  
  
  nf1 <- rep(numfactor, nrow(dobby))
  ni1 <- rep(numitems, nrow(dobby))
  
  placeb <- place[2]
  if(placeb%%2 == 0){
    signo1 <- rep(1, nrow(dobby))
  } else{signo1 <- rep(0, nrow(dobby))}
  
  acqh1 <- rep(h, nrow(dobby))
  acqsize1 <- rep(size, nrow(dobby)) 
  
  residual1 <- rep(res, nrow(dobby))
  pla1 <- rep(numfactor, nrow(dobby))
  
  numerodobletes <- cbind(conteo, nf, ni, acqh, acqsize, residual, pla, signo)
  dobletesencontrados <- cbind(dobby, nf1, ni1, acqh1, acqsize1, residual1, pla1, signo1)
  
  return(list(numerodobletes=numerodobletes, dobletesencontrados=dobletesencontrados, matrixsesgos1=matrixsesgos1,matrixsesgos2=matrixsesgos2, matrixsesgos3=matrixsesgos3, RMSEA1=RMSEA1, CFI1=CFI1 , TL1=TL1))
}



