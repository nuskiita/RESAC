
#TRANSNORMAL     Transform an initial variable to have the first four moments
#                of a standard normal distribution
#
#                The initial variable has only positive values and 
#                its distribution is rightly skewed 
#   x is expected to be previously transformed as x = log(Y)




Trans2Normal <- function(x) {
  source("newtonnor.R")
  N <- length(x)
  md <- mean(x)
  sx <- sd(x)
  z <- (1/sx) * (x - md)
  
  z2 <- z^2
  z3 <- z^3
  z4 <- z^4
  zp1 <- z2 - 1
  zp2 <- zp1^2
  zp3 <- zp1^3
  zp4 <- zp1^2
  
  t3 <- mean(z3)
  t4 <- mean(z4)
  pt2 <- mean(zp2)
  pt3 <- mean(zp3)
  pt4 <- mean(zp4)
  c1 <- cov(cbind(z, zp1))
  c1 <- c1[1, 2]
  c2 <- cov(cbind(z2, zp1))
  c2 <- c2[1, 2]
  c3 <- cov(cbind(z, zp2))
  c3 <- c3[1, 2]
  c4 <- cov(cbind(z3, zp1))
  c4 <- c4[1, 2]
  c5 <- cov(cbind(z, zp3))
  c5 <- c5[1, 2]
  c6 <- cov(cbind(z2, zp2))
  c6 <- c6[1, 2]
  
  #initial estimates for b1 and b2
  b1ini <- 0.95
  b2ini <- 0.15
  
  # nwton raphson estimates for b1 and b2
  res <- newtonnor(b1ini, b2ini, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6)
  
  b1 <- res$m
  b2 <- res$l
  # intercept estimate
  a <- -b2
  
  #t <- a + (b1 * z) + (b2 * z2)
  
  return(list(md = md, sx = sx, a = a, b1 = b1, b2 = b2))
}

