


newton <- function(a,b,c,skew, kurt){
  
  max_iter <- 25
  converge <- 1e-5
  
  fa<- a
  fb <- b
  fc <- c 
  
  f <- flfunc(fa, fb, fc, skew, kurt)
  
  for(i in 1:max_iter){
    if(max(abs(f))<converge){
      break
    }
    J <- flderiv(fa, fb, fc)
    
    delta <- -(solve(t(J)%*%J)%*%t(J)%*%f)
    fa <- delta[1] +fa
    fb <- delta[2] +fb
    fc <- delta[3] +fc
    
    f <- flfunc(fa, fb, fc, skew, kurt)
  }
  
  lista <- list(fa=fa, fb=fb, fc=fc)
  return(lista)
}
