# Fleishmanic
# 
# 


fleishmanic <- function(skew, kurt){
  A <- 0.95357 - 0.05679 * kurt + 0.03520 * skew^2 + 0.00133 * kurt^2;
  B <- 0.10007 * skew + 0.00844 * skew^3;
  C <- 0.30978 - 0.31655 * A;
  
  return(list(A=A, B=B, C=C))
}
