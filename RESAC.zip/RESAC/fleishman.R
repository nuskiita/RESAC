


fleishman <- function(b, c, d){
  b2 <- b * b
  c2 <- c * c
  d2 <- d * d
  bd <- b * d
  var <- b2 + 6*bd + 2*c2 + 15*d2
  skew <- 2 * c * (b2 + 24*bd + 105*d2 + 2)
  kurt <- 24 * (bd + c2 * (1 + b2 + 28*bd) + d2 * (12 + 48*bd + 141*c2 + 225*d2))
  
  lista <- list(var=var, skew=skew, kurt=kurt)
  return(lista)
}