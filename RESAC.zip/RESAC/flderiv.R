


flderiv <- function(b, c, d){
  
  b2 <- b * b
  c2 <-  c * c
  d2 <- d * d
  bd <- b * d
  df1db <- 2*b + 6*d
  df1dc <- 4*c
  df1dd <- 6*b + 30*d
  df2db <- 4*c * (b + 12*d)
  df2dc <- 2 * (b2 + 24*bd + 105*d2 + 2)
  df2dd <- 4 * c * (12*b + 105*d)
  df3db <- 24 * (d + c2 * (2*b + 28*d) + 48 * d^3)
  df3dc <- 48 * c * (1 + b2 + 28*bd + 141*d2)
  df3dd<-24 * (b + 28*b * c2 + 2 * d * (12 + 48*bd + 141*c2 + 225*d2) + d2 * (48*b + 450*d))
  
  PD <- matrix(c(df1db,df2db,df3db,df1dc,df2dc,df3dc,df1dd,df2dd,df3dd),ncol=3, byrow=FALSE)
  
  return(PD)
  
}
