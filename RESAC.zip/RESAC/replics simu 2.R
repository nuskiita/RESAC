#replicas simulación dos



replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
eg1 <- replic(replicas, N, numfactor, numitems, h, size, res, place)


db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg1t <- lapply(eg1, agregar_columnas, nuevas_columnas)


replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 1
res <- 0.2
place <- c(1,3)
eg2 <- replic(replicas, N, numfactor, numitems, h, size, res, place)

db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg2t <- lapply(eg2, agregar_columnas, nuevas_columnas)

replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 2
res <- 0.2
place <- c(1,3)
eg3 <- replic(replicas, N, numfactor, numitems, h, size, res, place)

db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg3t <- lapply(eg3, agregar_columnas, nuevas_columnas)

listadopriemro <- list(eg1t, eg2t, eg3t, eg4t, eg9t, eg10t, eg11t, eg12t)

save.image("listadoprimero.RData")
replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 2
res <- 0.2
place <- c(1,3)
eg4 <- replic(replicas, N, numfactor, numitems, h, size, res, place)



db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)


nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg4t <- lapply(eg4, agregar_columnas, nuevas_columnas)


replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,5)
eg5 <- replic(replicas, N, numfactor, numitems, h, size, res, place)


db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)


nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg5t <- lapply(eg5, agregar_columnas, nuevas_columnas)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 1
res <- 0.2
place <- c(1,5)
eg6 <- replic(replicas, N, numfactor, numitems, h, size, res, place)


db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)


nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg6t <- lapply(eg6, agregar_columnas, nuevas_columnas)




replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 2
res <- 0.2
place <- c(1,5)
eg7 <- replic(replicas, N, numfactor, numitems, h, size, res, place)


db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)


nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg7t <- lapply(eg7, agregar_columnas, nuevas_columnas)


replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 2
res <- 0.2
place <- c(1,5)
eg8 <- replic(replicas, N, numfactor, numitems, h, size, res, place)

db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(0, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)


nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg8t <- lapply(eg8, agregar_columnas, nuevas_columnas)



replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,2)
eg9 <- replic(replicas, N, numfactor, numitems, h, size, res, place)

db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg9t <- lapply(eg9, agregar_columnas, nuevas_columnas)



replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 1
res <- 0.2
place <- c(1,2)
eg10 <- replic(replicas, N, numfactor, numitems, h, size, res, place)




db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg10t <- lapply(eg10, agregar_columnas, nuevas_columnas)





replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 2
res <- 0.2
place <- c(1,2)
eg11 <- replic(replicas, N, numfactor, numitems, h, size, res, place)




db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg11t <- lapply(eg11, agregar_columnas, nuevas_columnas)





replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 2
res <- 0.2
place <- c(1,2)
eg12 <- replic(replicas, N, numfactor, numitems, h, size, res, place)



db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg12t <- lapply(eg12, agregar_columnas, nuevas_columnas)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,6)
eg13 <- replic(replicas, N, numfactor, numitems, h, size, res, place)

db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg13t <- lapply(eg13, agregar_columnas, nuevas_columnas)


replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 1
res <- 0.2
place <- c(1,6)
eg14 <- replic(replicas, N, numfactor, numitems, h, size, res, place)

db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg14t <- lapply(eg14, agregar_columnas, nuevas_columnas)



replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 2
res <- 0.2
place <- c(1,6)
eg15 <- replic(replicas, N, numfactor, numitems, h, size, res, place)


db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg15t <- lapply(eg15, agregar_columnas, nuevas_columnas)


replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 2
res <- 0.2
place <- c(1,6)
eg16 <- replic(replicas, N, numfactor, numitems, h, size, res, place)


db1 <- rep(place[1], replicas)
db2 <- rep(place[2], replicas)
sig <- rep(1, replicas)
nf <- rep(numfactor, replicas)
acqh <- rep(h, replicas)
acqs <- rep(size, replicas)

nuevas_columnas <- cbind(db1, db2, sig, nf, acqh, acqs)

agregar_columnas <- function(matriz, nuevas_columnas) {
  matriz_con_columnas <- cbind(matriz, nuevas_columnas)
  return(matriz_con_columnas)
}

eg16t <- lapply(eg16, agregar_columnas, nuevas_columnas)








sesgocontrol1pos <- lapply(list(eg1t, eg2t, eg3t, eg4t), function(x) x$sesgocontrol)

sesgocontrol1neg <- lapply(list(eg9t, eg10t, eg11t, eg12t), function(x) x$sesgocontrol)

matriz_sesgocontrol1pos <- do.call(rbind, sesgocontrol1pos)

matrizsesgocontrol1pos <- cbind(matriz_sesgocontrol1pos, rep(0, nrow(matriz_sesgocontrol1pos)))

sesgocontrol1posdob <- matrizsesgocontrol1pos[,c(1,3,7,8,9,10,11,12,13)]

matriz_sesgocontrol1neg <- do.call(rbind, sesgocontrol1neg)

matrizsesgocontrol1neg <- cbind(matriz_sesgocontrol1neg, rep(0, nrow(matriz_sesgocontrol1neg)))

sesgocontrol1negdob <- matrizsesgocontrol1pos[,c(1,2,7,8,9,10,11,12,13)]


sesgocontrol2pos <- lapply(list(eg5t, eg6t, eg7t, eg8t), function(x) x$sesgocontrol)

sesgocontrol2neg <- lapply(list(eg13t, eg14t, eg15t, eg16t), function(x) x$sesgocontrol)

matriz_sesgocontrol2pos <- do.call(rbind, sesgocontrol2pos)

matrizsesgocontrol2pos <- cbind(matriz_sesgocontrol2pos, rep(0, nrow(matriz_sesgocontrol2pos)))

sesgocontrol2posdob <- matrizsesgocontrol2pos[,c(1,5,9,10,11,12,13,14,15)]

matriz_sesgocontrol2neg <- do.call(rbind, sesgocontrol2neg)

matrizsesgocontrol2neg <- cbind(matriz_sesgocontrol2neg, rep(0, nrow(matriz_sesgocontrol2neg)))

sesgocontrol2negdob <- matrizsesgocontrol2pos[,c(1,6,9,10,11,12,13,14,15)]


tablapreuba <- rbind(sesgocontrol1posdob, sesgocontrol1negdob,sesgocontrol2posdob, sesgocontrol2negdob)


sesgoall1posdob[,5]=0
sesgoall1negdob[,5]=1
sesgoall2posdob[,5]=0
sesgoall2negdob[,5]=1

sesgoacq1pos <- lapply(list(eg1t, eg2t, eg3t, eg4t), function(x) x$sesgoacq)

sesgoacq1neg <- lapply(list(eg9t, eg10t, eg11t, eg12t), function(x) x$sesgoacq)

matriz_sesgoacq1pos <- do.call(rbind, sesgoacq1pos)

matrizsesgoacq1pos <- cbind(matriz_sesgoacq1pos, rep(1, nrow(matriz_sesgoacq1pos)))

sesgoacq1posdob <- matrizsesgoacq1pos[,c(1,3,7,8,9,10,11,12,13)]

matriz_sesgoacq1neg <- do.call(rbind, sesgoacq1neg)

matrizsesgoacq1neg <- cbind(matriz_sesgoacq1neg, rep(1, nrow(matriz_sesgoacq1neg)))

sesgoacq1negdob <- matrizsesgoacq1pos[,c(1,2,7,8,9,10,11,12,13)]


sesgoacq2pos <- lapply(list(eg5t, eg6t, eg7t, eg8t), function(x) x$sesgoacq)

sesgoacq2neg <- lapply(list(eg13t, eg14t, eg15t, eg16t), function(x) x$sesgoacq)

matriz_sesgoacq2pos <- do.call(rbind, sesgoacq2pos)

matrizsesgoacq2pos <- cbind(matriz_sesgoacq2pos, rep(1, nrow(matriz_sesgoacq2pos)))

sesgoacq2posdob <- matrizsesgoacq2pos[,c(1,5,9,10,11,12,13,14,15)]

matriz_sesgoacq2neg <- do.call(rbind, sesgoacq2neg)

matrizsesgoacq2neg <- cbind(matriz_sesgoacq2neg, rep(1, nrow(matriz_sesgoacq2neg)))

sesgoacq2negdob <- matrizsesgoacq2pos[,c(1,6,9,10,11,12,13,14,15)]






sesgores1pos <- lapply(list(eg1t, eg2t, eg3t, eg4t), function(x) x$sesgores)

sesgores1neg <- lapply(list(eg9t, eg10t, eg11t, eg12t), function(x) x$sesgores)

matriz_sesgores1pos <- do.call(rbind, sesgores1pos)

matrizsesgores1pos <- cbind(matriz_sesgores1pos, rep(2, nrow(matriz_sesgores1pos)))

sesgores1posdob <- matrizsesgores1pos[,c(1,3,7,8,9,10,11,12,13)]

matriz_sesgores1neg <- do.call(rbind, sesgores1neg)

matrizsesgores1neg <- cbind(matriz_sesgores1neg, rep(2, nrow(matriz_sesgores1neg)))

sesgores1negdob <- matrizsesgores1pos[,c(1,2,7,8,9,10,11,12,13)]


sesgores2pos <- lapply(list(eg5t, eg6t, eg7t, eg8t), function(x) x$sesgores)

sesgores2neg <- lapply(list(eg13t, eg14t, eg15t, eg16t), function(x) x$sesgores)

matriz_sesgores2pos <- do.call(rbind, sesgores2pos)

matrizsesgores2pos <- cbind(matriz_sesgores2pos, rep(2, nrow(matriz_sesgores2pos)))

sesgores2posdob <- matrizsesgores2pos[,c(1,5,9,10,11,12,13,14,15)]

matriz_sesgores2neg <- do.call(rbind, sesgores2neg)

matrizsesgores2neg <- cbind(matriz_sesgores2neg, rep(2, nrow(matriz_sesgores2neg)))

sesgores2negdob <- matrizsesgores2pos[,c(1,6,9,10,11,12,13,14,15)]





sesgoall1pos <- lapply(list(eg1t, eg2t, eg3t, eg4t), function(x) x$sesgoall)

sesgoall1neg <- lapply(list(eg9t, eg10t, eg11t, eg12t), function(x) x$sesgoall)

matriz_sesgoall1pos <- do.call(rbind, sesgoall1pos)

matrizsesgoall1pos <- cbind(matriz_sesgoall1pos, rep(3, nrow(matriz_sesgoall1pos)))

sesgoall1posdob <- matrizsesgoall1pos[,c(1,3,7,8,9,10,11,12,13)]

matriz_sesgoall1neg <- do.call(rbind, sesgoall1neg)

matrizsesgoall1neg <- cbind(matriz_sesgoall1neg, rep(3, nrow(matriz_sesgoall1neg)))

sesgoall1negdob <- matrizsesgoall1pos[,c(1,2,7,8,9,10,11,12,13)]


sesgoall2pos <- lapply(list(eg5t, eg6t, eg7t, eg8t), function(x) x$sesgoall)

sesgoall2neg <- lapply(list(eg13t, eg14t, eg15t, eg16t), function(x) x$sesgoall)

matriz_sesgoall2pos <- do.call(rbind, sesgoall2pos)

matrizsesgoall2pos <- cbind(matriz_sesgoall2pos, rep(3, nrow(matriz_sesgoall2pos)))

sesgoall2posdob <- matrizsesgoall2pos[,c(1,5,9,10,11,12,13,14,15)]

matriz_sesgoall2neg <- do.call(rbind, sesgoall2neg)

matrizsesgoall2neg <- cbind(matriz_sesgoall2neg, rep(3, nrow(matriz_sesgoall2neg)))

sesgoall2negdob <- matrizsesgoall2pos[,c(1,6,9,10,11,12,13,14,15)]




datoscompletos <- rbind(sesgocontrol1posdob,sesgocontrol1negdob,
                        sesgocontrol2posdob,sesgocontrol2negdob, 
                        sesgoacq1posdob,sesgoacq1negdob,
                        sesgoacq2posdob,sesgoacq2negdob,
                        sesgores1posdob,sesgores1negdob,
                        sesgores2posdob,sesgores2negdob,
                        sesgoall1posdob,sesgoall1negdob,
                        sesgoall2posdob,sesgoall2negdob)
dim(datoscompletos)
library(MASS)
write.matrix(datoscompletos, "datoscompletosanova2.txt")
head.matrix(datoscompletos)

datos <- as.data.frame(datoscompletos)

for(i in 1:nrow(datoscompletos)){
  if(datoscompletos[i,4] %% 2 == 1){
    datoscompletos[i,5]==0
  } else{datoscompletos[i,5]==1}
}
if(datoscompletos[,4] %% 2 == 1){
  datoscompletos[,5]==0
} else{datoscompletos[,5]==1}

