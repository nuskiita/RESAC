
# 1. Ensure that you are currently working in the directory that contains all the code files.
# 2. source("index.R")
# 3. Verify that all the functions from the MORGANA folder have been successfully loaded.

source("index.R")

library(MASS)
install.packages("psych")
library(psych)
install.packages("EFA.MRFA")
library(EFA.MRFA)



# load bentler.dat
Z <- database
conver <- 0.0001
maxiter <- 100
display <- 1
nrs <- 10

#Factors present in the population
r <- 2

#Expected pattern in the population for Procrustes rotation
H <- matrix(c(
  1, 0,
  1, 0,
  1, 0,
  1, 0,
  1, 0,
  0, 1,
  0, 1,
  0, 1,
  0, 1,
  0, 1
), ncol = 2, byrow = TRUE)

#The data is stored in X
N <- nrow(Z)
m <- ncol(Z)

# Pearson's R
cor <- 2
R <- cor(Z)

# MORGANA EXPLORATORY FACTOR ANALYSIS
cat("==================================================================\n")
cat("Morgana's Exploratory Factor Analysis\n")
cat("==================================================================\n")

#EXTRACTION
result <- MorganaEFA(Z, r, conver, maxiter, cor)
A <- result$A
RESCOV <- result$RESCOV
RESCOR <- result$RESCOR
doubletsEFA <- result$doublets
nd <- nrow(doubletsEFA)
RES <- zeros(nd, 3)
for (k in 1:nd) {
  RES[k, 1] <- doubletsEFA[k, 1]
  RES[k, 2] <- doubletsEFA[k, 2]
  RES[k, 3] <- RESCOR[doubletsEFA[k, 1], doubletsEFA[k, 2]]
}

cat("\n")
cat("Goodness of fit indices\n")
cat("\n")


result <- LoseferMorganaH0(A, RESCOR, doubletsEFA[, c(1, 2)], N, 5000)
v <- result$v
vv <- result$vv
a_n <- result$a_n
b1_n <- result$b1_n
b2_n <- result$b2_n
a_f <- result$a_f
b_f <- result$b_f
c_f <- result$c_f
d_f <- result$d_f

result <- LoseferMorgana(R, A, N, RESCOR, nd, v, vv, a_n, b1_n, b2_n, a_f, b_f, c_f, d_f, display)
Um1 <- result$Um1
d1 <- result$d1
RMSEA1 <- result$RMSEA1
CFI1 <- result$CFI1
TL1 <- result$TL1



cat("\n")
cat("EREC for pairs of doublets\n")
cat("\n")
print(doubletsEFA)
cat("\n")
cat("Residuals for pairs of doublets\n")
cat("\n")
print(RES)
cat("\n")

# MORGANA CONFIRMATORY FACTOR ANALYSIS
doublets <- matrix(c(
  1, 2,
  6, 7
), ncol = 2, byrow = TRUE)
nd <- nrow(doublets)

cat("==================================================================\n")
cat("Morgana's Confirmatory Factor Analysis\n")
cat("==================================================================\n")

# Extraction
source("MorganaCFA.R")
result <- MorganaCFA(Z, r, conver, maxiter, cor, doublets)
A <- result$A
RESCOV <- result$RESCOV
RESCOR <- result$RESCOR
doubletsCFA <- result$doublets
RES <- matrix(0, nrow = nd, ncol = 3)
for (k in 1:nd) {
  RES[k, 1] <- doubletsCFA[k, 1]
  RES[k, 2] <- doubletsCFA[k, 2]
  RES[k, 3] <- RESCOR[doubletsCFA[k, 1], doubletsCFA[k, 2]]
}

cat("\n")
cat("Goodness of fit indices\n")
cat("\n")
source("LoseferMorganaH0.R")
result <- LoseferMorganaH0(A, RESCOR, doublets[, c(1, 2)], N, 5000)
v <- result$v
vv <- result$vv
a_n <- result$a_n
b1_n <- result$b1_n
b2_n <- result$b2_n
a_f <- result$a_f
b_f <- result$b_f
c_f <- result$c_f
d_f <- result$d_f
source("LoseferMorgana.R")
result <- LoseferMorgana(R, A, N, RESCOR, nd, v, vv, a_n, b1_n, b2_n, a_f, b_f, c_f, d_f, display)
Um1 <- result$Um1
d1 <- result$d1
RMSEA1 <- result$RMSEA1
CFI1 <- result$CFI1
TL1 <- result$TL1

cat("\n")
cat("Pairs of doublets\n")
cat("\n")
print(doubletsCFA)
cat("\n")
cat("Residuals for pairs of doublets\n")
cat("\n")
print(RES)
cat("\n")
