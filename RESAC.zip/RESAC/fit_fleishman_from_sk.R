# fit_fleishman_from_sk


fit_fleishman_from_sk <- function(skew, kurt){
  A <- NaN
  B <- NaN
  C <- NaN
  
  op <- (-1.13168 + 1.58837 * (skew^2))
  
  if(kurt < op){
    A <- NaN
    B <- NaN
    C <- NaN
  } else{
    abc <- fleishmanic(skew, kurt)
    ABC <- newton(abc$A, abc$B, abc$C, skew, kurt)
    A <- ABC$fa
    B <- ABC$fb
    C <- ABC$fc
  }
  lista <- list(A=A, B=B, C=C)
  return(lista)
}
