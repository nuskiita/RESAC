



# Majoritation of a vector
# 
# Ff <-  vector to be majorized
# p <- method
# PHI <- SOLUTION
# 

urbmaj <- function(Ff){
  n <- length(Ff)
  m <- ncol(Ff)
  PHI <- Ff*Ff
  m <- mean(PHI)
  s <- sqrt(var(PHI) * (n - 1) / n)
  cc <- m+s/4
  
  for(i in 1:n){
    if(PHI[i] < cc){
      PHI[i] <- 0
    }
  }
  return(PHI)
}