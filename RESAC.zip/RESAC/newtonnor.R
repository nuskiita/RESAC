#NEWTON        Metodo de Newton Raphson en 2 dimensiones


source("f1.R")
source("f2.R")
source("sf1.R")
source("sf2.R")
source("sf3.R")
source("sf4.R")


newtonnor <- function(xini, yini, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6) {
  x <- xini
  y <- yini
  
  for (i in 1:8) {
    X <- c(x, y)
    F <- c(f1(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6), f2(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6))
    J1 <- c(sf1(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6), sf2(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6))
    J2 <- c(sf3(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6), sf4(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6))
    J <- rbind(J1, J2)
    X <- X - solve(J) %*% F
    x <- X[1]
    y <- X[2]
  }
  
  
  m <- x
  l <- y
  return(list(m = m, l = l))
  }
  
  

