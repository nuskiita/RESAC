
##################################
###                            ###
###           PROMIN           ### 
###                            ###
##################################


# Promin semi-specified rotation using majorization
# Ff <- Factor solution to be rotated
# Tt  <- Transformtion matrix to the pattern
# U  <- Transformation matrix tu the structure


promin <- function(Ff, conv, nrs) {
  n <- nrow(Ff)
  m <- ncol(Ff)
  
  Tv <- wvarim(Ff, conv, nrs)
  
  C <- normalize(Ff %*% Tv$Tr)
  B <- matrix(0, n, m)
  for (j in 1:m) {
    B[, j] <- urbmaj(C[, j])
  }
  
  W <- matrix(0, n, m)
  for (j in 1:m) {
    for (i in 1:n) {
      if (B[i, j] > 0.0001) {
        W[i, j] <- 1.0
      }
    }
  }
  
  res <- tarrotob(F, W, conv)
  A <- res$A
  Tt <- res$Tt
  PHI <- res$PHI
  ST <- res$ST
  
  U <- solve(Tt)
  
  return(list(Tt = Tt, U = U, W = W))
}
