
#######################
###                 ###
###       VEC       ### 
###                 ###
#######################

# It buils a vec vector from the A matrix
# 
# A <- matrix
# a <- output vector 


vec <- function(A){
  n <- nrow(A)
  m <- ncol(A)
  
  a <- c(0)
  
  for(i in 1:m){
    a <- c(a, A[,i]) 
  }
  return(a)
}