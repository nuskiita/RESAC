# replicas


replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
conver <- 0.000001
maxiter <- 250
g1 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 1
res <- 0.2
place <- c(1,3)
g2 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 2
res <- 0.2
place <- c(1,3)
g3 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 2
res <- 0.2
place <- c(1,3)
g4 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 10
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,5)
g5P <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 1
res <- 0.2
place <- c(1,5)
g6 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 2
res <- 0.2
place <- c(1,5)
g7 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 2
res <- 0.2
place <- c(1,5)
g8 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)




replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,2)
g9 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 1
res <- 0.2
place <- c(1,2)
g10 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 2
res <- 0.2
place <- c(1,2)
g11 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 2
res <- 0.2
place <- c(1,2)
g12 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,6)
g13 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 1
res <- 0.2
place <- c(1,6)
g14 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 2
res <- 0.2
place <- c(1,6)
g15 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 500
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 2
res <- 0.2
place <- c(1,6)
g16 <- replicascompletas(replicas, N, numfactor, numitems, h, size, res, place)



replicas <- 3
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
w000 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)



replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,3)
w1 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 1
res <- 0.2
place <- c(1,3)
w2 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 2
res <- 0.2
place <- c(1,3)
w3 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 2
res <- 0.2
place <- c(1,3)
w4 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,5)
w5 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 1
res <- 0.2
place <- c(1,5)
w6 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 2
res <- 0.2
place <- c(1,5)
w7 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 2
res <- 0.2
place <- c(1,5)
w8 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)




replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 1
res <- 0.2
place <- c(1,2)
w9 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 1
res <- 0.2
place <- c(1,2)
w10 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 1
size <- 2
res <- 0.2
place <- c(1,2)
w11 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 1
numitems <- 6
h <- 2
size <- 2
res <- 0.2
place <- c(1,2)
w12 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 1
res <- 0.2
place <- c(1,6)
w13 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 1
res <- 0.2
place <- c(1,6)
w14 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 1
size <- 2
res <- 0.2
place <- c(1,6)
w15 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)

replicas <- 1000
N <- 500
numfactor <- 2
numitems <- 8
h <- 2
size <- 2
res <- 0.2
place <- c(1,6)
w16 <- replicasnosiren(replicas, N, numfactor, numitems, h, size, res, place)


# listas contando los corregidos y no corregidos

elementos001 <- lapply(list(g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11, g12, g13, g14, g15, g16), function(x) x$numerodobletes)

matriz_elementos001 <- do.call(rbind, elementos001)

matriz_elementos01 <- cbind(matriz_elementos001, rep(0, nrow(matriz_elementos001)))

elementos100 <- lapply(list(w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16), function(x) x$numerodobletes)

matriz_elementos100 <- do.call(rbind, elementos100)

matriz_elementos10 <- cbind(matriz_elementos100, rep(1, nrow(matriz_elementos100)))


matriz_elementos1 <-rbind(matriz_elementos01,matriz_elementos10)



elementos002 <- lapply(list(g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11, g12, g13, g14, g15, g16), function(x) x$dobletesencontrados)

matriz_elementos002 <- do.call(rbind, elementos002)

matriz_elementos02 <- cbind(matriz_elementos002, rep(0, nrow(matriz_elementos002)))

elementos200 <- lapply(list(w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16), function(x) x$dobletesencontrados)

matriz_elementos200 <- do.call(rbind, elementos200)

matriz_elementos20 <- cbind(matriz_elementos200, rep(1, nrow(matriz_elementos200)))


matriz_elementos2 <-rbind(matriz_elementos02,matriz_elementos20)




numerodobletes <- matriz_elementos1

dobletesencontrados <- matriz_elementos2

library(MASS)
write.matrix(matriz_elementos1, "numerodobletes.dat")
write.matrix(matriz_elementos2, "dobletesencontrados.dat")
