
##############################
###                        ###
###           nrm          ### 
###                        ###
##############################

nrm <- function(A){
  # makes columnwise normalized version of A
  n <- nrow(A)
  m <- ncol(A)
  
  d <- sum(A^2)
  w <- d > 1e-30
  N <- matrix(0, n, m)
  
  if(sum(w)>0){
    N[,w]<- A[,w]/sqrt(d[w])
  }
  retrun(N)
}