

#############################
###                       ###
###        sort           ### 
###                       ###
#############################

# vector_sort: numeros de mayor a menor
# j <- posici�n de los numeros en el vector de origen 
sort <- function(vector, descend=TRUE){
  if(descend==TRUE){
    J <- order(vector,decreasing=TRUE)
    vector_sort <- vector[J]
  }
  else{
    J <- order(vector,decreasing=FALSE)
    vector_sort <- vector[J]
  }
 
  
  return(cbind(vector_sort, J))
}

