

#####################
###               ###
###      eye      ### 
###               ###
#####################

#matriz identidad
eye <- function(a){
  
  ret <- diag(a)
  
  return(ret)
}

