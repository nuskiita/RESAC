
#####################
###               ###
###      SSQ      ### 
###               ###
#####################

#  Es la suma de los cuadrados de los elementos de la matriz A 
# 
ssq <- function(a){
  t <- sum(sum(a^2))
  return(t)
}
