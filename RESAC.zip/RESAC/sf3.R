# sf3: aproximacion mediante la secante. derivada de f2 con respecto a x

source("f2.R")
sf3 <- function(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6) {
  x1 <- x + 0.00001
  tmp1 <- f2(x1, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6)
  tmp2 <- f2(x, y, t3, t4, pt2, pt3, pt4, c1, c2, c3, c4, c5, c6)
  sf3 <- (tmp1 - tmp2) / 0.00001
  
  return(sf3)
}