
#######################
###                 ###
###      zeros      ### 
###                 ###
#######################


zeros <- function(rows, cols){
  z <- matrix(c(0), ncol=cols, nrow=rows)
  return(z)
}

